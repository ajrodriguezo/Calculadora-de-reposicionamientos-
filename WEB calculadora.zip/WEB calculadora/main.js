function arbol(Edad, IMC) {
  let result;

  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC <= 24.45 &&
    Edad > 35.5 &&
    Edad <= 64.0 &&
    Edad <= 58.5 &&
    Edad <= 57.5 &&
    IMC > 22.5 &&
    IMC <= 24.35
  ) {
    result = 10.833;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC <= 24.45 &&
    Edad > 35.5 &&
    Edad <= 64.0 &&
    Edad <= 58.5 &&
    Edad <= 57.5 &&
    IMC <= 22.5 &&
    IMC > 21.55
  ) {
    result = 7.667;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC > 24.45 &&
    IMC > 24.55 &&
    Edad <= 58.5 &&
    IMC > 25.15 &&
    Edad > 41.5 &&
    Edad > 46.5 &&
    Edad <= 57.0
  ) {
    result = 10.8;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC > 24.45 &&
    IMC > 24.55 &&
    Edad <= 58.5 &&
    IMC > 25.15 &&
    Edad <= 41.5 &&
    IMC > 25.65 &&
    Edad > 34.0
  ) {
    result = 13.8;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC > 24.45 &&
    IMC > 24.55 &&
    Edad <= 58.5 &&
    IMC <= 25.15 &&
    IMC > 24.895 &&
    Edad <= 54.0 &&
    Edad > 41.0
  ) {
    result = 16.8;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC <= 17.15 &&
    Edad > 20.0
  ) {
    result = 8.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC > 26.825 &&
    IMC > 26.95 &&
    IMC <= 28.045 &&
    IMC <= 27.85 &&
    Edad <= 42.0 &&
    Edad > 31.5 &&
    Edad > 38.0
  ) {
    result = 10.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC > 26.825 &&
    IMC > 26.95 &&
    IMC <= 28.045 &&
    IMC <= 27.85 &&
    Edad > 42.0 &&
    Edad <= 53.5 &&
    Edad <= 45.5
  ) {
    result = 6.667;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC > 24.45 &&
    IMC > 24.55 &&
    Edad <= 58.5 &&
    IMC > 25.15 &&
    Edad > 41.5 &&
    Edad <= 46.5 &&
    IMC <= 26.0
  ) {
    result = 5.333;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad > 54.5 &&
    Edad > 56.0 &&
    IMC <= 32.4
  ) {
    result = 6.0;
  }
  if (Edad > 67.5 && Edad > 71.5 && IMC <= 25.4 && IMC > 20.8 && Edad > 79.5) {
    result = 11.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC > 24.45 &&
    IMC > 24.55 &&
    Edad <= 58.5 &&
    IMC <= 25.15 &&
    IMC <= 24.895 &&
    Edad <= 46.5 &&
    Edad > 42.0
  ) {
    result = 6.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC <= 24.45 &&
    Edad > 35.5 &&
    Edad <= 64.0 &&
    Edad <= 58.5 &&
    Edad <= 57.5 &&
    IMC <= 22.5 &&
    IMC <= 21.55
  ) {
    result = 11.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC <= 26.825 &&
    Edad <= 34.5
  ) {
    result = 8.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad <= 50.0 &&
    IMC > 30.55 &&
    Edad > 37.5 &&
    IMC <= 32.65 &&
    IMC <= 32.375 &&
    IMC > 30.92
  ) {
    result = 6.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC <= 24.45 &&
    Edad <= 35.5 &&
    IMC <= 23.7 &&
    Edad <= 32.5 &&
    IMC <= 22.5
  ) {
    result = 7.5;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad <= 50.0 &&
    IMC <= 30.55 &&
    Edad <= 33.5
  ) {
    result = 6.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC > 24.45 &&
    IMC > 24.55 &&
    Edad <= 58.5 &&
    IMC <= 25.15 &&
    IMC <= 24.895 &&
    Edad <= 46.5 &&
    Edad <= 42.0
  ) {
    result = 10.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC <= 24.45 &&
    Edad <= 35.5 &&
    IMC <= 23.7 &&
    Edad > 32.5 &&
    Edad > 33.5
  ) {
    result = 4.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC > 24.45 &&
    IMC > 24.55 &&
    Edad <= 58.5 &&
    IMC > 25.15 &&
    Edad > 41.5 &&
    Edad <= 46.5 &&
    IMC > 26.0
  ) {
    result = 10.5;
  }
  if (Edad > 67.5 && Edad > 71.5 && IMC > 25.4 && Edad <= 73.5) {
    result = 7.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC > 26.825 &&
    IMC > 26.95 &&
    IMC <= 28.045 &&
    IMC <= 27.85 &&
    Edad <= 42.0 &&
    Edad > 31.5 &&
    Edad <= 38.0
  ) {
    result = 11.5;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC <= 24.45 &&
    Edad > 35.5 &&
    Edad <= 64.0 &&
    Edad <= 58.5 &&
    Edad <= 57.5 &&
    IMC > 22.5 &&
    IMC > 24.35
  ) {
    result = 7.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad <= 24.5
  ) {
    result = 0.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC > 24.45 &&
    IMC > 24.55 &&
    Edad > 58.5
  ) {
    result = 18.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC <= 24.45 &&
    Edad > 35.5 &&
    Edad <= 64.0 &&
    Edad <= 58.5 &&
    Edad > 57.5 &&
    IMC <= 22.4
  ) {
    result = 16.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC > 24.45 &&
    IMC > 24.55 &&
    Edad <= 58.5 &&
    IMC > 25.15 &&
    Edad > 41.5 &&
    Edad > 46.5 &&
    Edad > 57.0
  ) {
    result = 6.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC <= 24.45 &&
    Edad > 35.5 &&
    Edad <= 64.0 &&
    Edad <= 58.5 &&
    Edad > 57.5 &&
    IMC > 22.4
  ) {
    result = 11.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC <= 24.45 &&
    Edad > 35.5 &&
    Edad <= 64.0 &&
    Edad > 58.5 &&
    IMC <= 23.955 &&
    IMC <= 23.655
  ) {
    result = 3.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC <= 24.45 &&
    Edad > 35.5 &&
    Edad <= 64.0 &&
    Edad > 58.5 &&
    IMC <= 23.955 &&
    IMC > 23.655
  ) {
    result = 1.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC > 24.45 &&
    IMC > 24.55 &&
    Edad <= 58.5 &&
    IMC <= 25.15 &&
    IMC > 24.895 &&
    Edad > 54.0
  ) {
    result = 9.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC <= 24.45 &&
    Edad > 35.5 &&
    Edad <= 64.0 &&
    Edad > 58.5 &&
    IMC > 23.955
  ) {
    result = 8.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC <= 24.45 &&
    Edad > 35.5 &&
    Edad > 64.0
  ) {
    result = 15.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad <= 29.0 &&
    IMC <= 27.345
  ) {
    result = 5.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC > 24.45 &&
    IMC <= 24.55
  ) {
    result = 20.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC > 24.45 &&
    IMC > 24.55 &&
    Edad <= 58.5 &&
    IMC > 25.15 &&
    Edad <= 41.5 &&
    IMC > 25.65 &&
    Edad <= 34.0
  ) {
    result = 15.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC > 24.45 &&
    IMC > 24.55 &&
    Edad <= 58.5 &&
    IMC > 25.15 &&
    Edad <= 41.5 &&
    IMC <= 25.65
  ) {
    result = 6.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad <= 25.5
  ) {
    result = 18.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC > 24.45 &&
    IMC > 24.55 &&
    Edad <= 58.5 &&
    IMC <= 25.15 &&
    IMC <= 24.895 &&
    Edad > 46.5 &&
    Edad > 51.0
  ) {
    result = 16.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC > 24.45 &&
    IMC > 24.55 &&
    Edad <= 58.5 &&
    IMC <= 25.15 &&
    IMC > 24.895 &&
    Edad <= 54.0 &&
    Edad <= 41.0
  ) {
    result = 10.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC > 24.45 &&
    IMC > 24.55 &&
    Edad <= 58.5 &&
    IMC <= 25.15 &&
    IMC <= 24.895 &&
    Edad > 46.5 &&
    Edad <= 51.0
  ) {
    result = 12.0;
  }
  if (
    Edad > 67.5 &&
    Edad > 71.5 &&
    IMC > 25.4 &&
    Edad > 73.5 &&
    IMC > 26.1 &&
    IMC > 29.7
  ) {
    result = 3.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC <= 24.45 &&
    Edad <= 35.5 &&
    IMC > 23.7
  ) {
    result = 11.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC <= 24.45 &&
    Edad <= 35.5 &&
    IMC <= 23.7 &&
    Edad > 32.5 &&
    Edad <= 33.5
  ) {
    result = 1.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC <= 17.3
  ) {
    result = 25.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad <= 29.5 &&
    Edad <= 21.5 &&
    Edad <= 20.5 &&
    Edad <= 18.5
  ) {
    result = 9.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad <= 29.5 &&
    Edad <= 21.5 &&
    Edad <= 20.5 &&
    Edad > 18.5 &&
    Edad <= 19.5
  ) {
    result = 8.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad <= 29.5 &&
    Edad <= 21.5 &&
    Edad <= 20.5 &&
    Edad > 18.5 &&
    Edad > 19.5
  ) {
    result = 7.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad <= 29.5 &&
    Edad <= 21.5 &&
    Edad > 20.5
  ) {
    result = 1.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad <= 29.5 &&
    Edad > 21.5 &&
    Edad <= 22.5 &&
    IMC <= 20.0
  ) {
    result = 14.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad <= 29.5 &&
    Edad > 21.5 &&
    Edad <= 22.5 &&
    IMC > 20.0
  ) {
    result = 16.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad <= 29.5 &&
    Edad > 21.5 &&
    Edad > 22.5 &&
    IMC <= 20.45
  ) {
    result = 6.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad <= 29.5 &&
    Edad > 21.5 &&
    Edad > 22.5 &&
    IMC > 20.45 &&
    Edad <= 27.5 &&
    Edad <= 26.5 &&
    IMC <= 22.5
  ) {
    result = 16.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad <= 29.5 &&
    Edad > 21.5 &&
    Edad > 22.5 &&
    IMC > 20.45 &&
    Edad <= 27.5 &&
    Edad <= 26.5 &&
    IMC > 22.5
  ) {
    result = 5.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad <= 29.5 &&
    Edad > 21.5 &&
    Edad > 22.5 &&
    IMC > 20.45 &&
    Edad <= 27.5 &&
    Edad > 26.5
  ) {
    result = 20.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad <= 29.5 &&
    Edad > 21.5 &&
    Edad > 22.5 &&
    IMC > 20.45 &&
    Edad > 27.5 &&
    IMC <= 23.0 &&
    IMC <= 22.05
  ) {
    result = 7.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad <= 29.5 &&
    Edad > 21.5 &&
    Edad > 22.5 &&
    IMC > 20.45 &&
    Edad > 27.5 &&
    IMC <= 23.0 &&
    IMC > 22.05
  ) {
    result = 9.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad <= 29.5 &&
    Edad > 21.5 &&
    Edad > 22.5 &&
    IMC > 20.45 &&
    Edad > 27.5 &&
    IMC > 23.0
  ) {
    result = 12.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad > 29.5 &&
    IMC <= 21.485 &&
    IMC <= 21.235
  ) {
    result = 16.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad > 29.5 &&
    IMC <= 21.485 &&
    IMC > 21.235
  ) {
    result = 29.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad > 29.5 &&
    IMC > 21.485 &&
    IMC <= 22.4
  ) {
    result = 16.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC <= 24.25 &&
    Edad > 29.5 &&
    IMC > 21.485 &&
    IMC > 22.4
  ) {
    result = 10.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC > 24.25 &&
    Edad <= 21.5
  ) {
    result = 21.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad <= 31.5 &&
    IMC > 24.25 &&
    Edad > 21.5
  ) {
    result = 27.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC <= 20.9 &&
    IMC <= 19.65 &&
    Edad <= 55.0
  ) {
    result = 8.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC <= 20.9 &&
    IMC <= 19.65 &&
    Edad > 55.0 &&
    Edad <= 62.5
  ) {
    result = 15.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC <= 20.9 &&
    IMC <= 19.65 &&
    Edad > 55.0 &&
    Edad > 62.5
  ) {
    result = 10.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC <= 20.9 &&
    IMC > 19.65 &&
    Edad <= 53.0 &&
    Edad <= 40.5
  ) {
    result = 19.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC <= 20.9 &&
    IMC > 19.65 &&
    Edad <= 53.0 &&
    Edad > 40.5
  ) {
    result = 13.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC <= 20.9 &&
    IMC > 19.65 &&
    Edad > 53.0
  ) {
    result = 26.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC > 17.15 &&
    IMC > 17.3 &&
    Edad > 31.5 &&
    IMC > 20.9 &&
    IMC <= 24.45 &&
    Edad <= 35.5 &&
    IMC <= 23.7 &&
    Edad <= 32.5 &&
    IMC > 22.5
  ) {
    result = 5.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad <= 29.0 &&
    IMC > 27.345
  ) {
    result = 1.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC > 26.825 &&
    IMC <= 26.95 &&
    Edad <= 50.5
  ) {
    result = 14.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC <= 26.825 &&
    Edad > 34.5 &&
    Edad <= 36.0
  ) {
    result = 7.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC > 33.75 &&
    Edad > 22.0 &&
    IMC > 35.0 &&
    IMC <= 38.05 &&
    IMC > 35.85 &&
    Edad > 41.5 &&
    IMC > 37.5
  ) {
    result = 7.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad <= 50.0 &&
    IMC > 30.55 &&
    Edad > 37.5 &&
    IMC > 32.65
  ) {
    result = 1.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad > 50.0 &&
    IMC <= 29.75 &&
    Edad <= 52.5
  ) {
    result = 15.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad > 50.0 &&
    IMC <= 29.75 &&
    Edad > 52.5
  ) {
    result = 12.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad > 50.0 &&
    IMC > 29.75
  ) {
    result = 8.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad > 54.5 &&
    Edad <= 56.0
  ) {
    result = 1.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad > 54.5 &&
    Edad > 56.0 &&
    IMC > 32.4
  ) {
    result = 10.0;
  }
  if (Edad <= 67.5 && IMC > 29.15 && IMC > 33.75 && Edad <= 22.0) {
    result = 1.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC > 33.75 &&
    Edad > 22.0 &&
    IMC <= 35.0 &&
    Edad <= 41.0
  ) {
    result = 18.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC > 33.75 &&
    Edad > 22.0 &&
    IMC <= 35.0 &&
    Edad > 41.0
  ) {
    result = 16.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC > 33.75 &&
    Edad > 22.0 &&
    IMC > 35.0 &&
    IMC <= 38.05 &&
    IMC <= 35.85 &&
    Edad <= 37.0
  ) {
    result = 10.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC > 33.75 &&
    Edad > 22.0 &&
    IMC > 35.0 &&
    IMC <= 38.05 &&
    IMC <= 35.85 &&
    Edad > 37.0
  ) {
    result = 11.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC > 33.75 &&
    Edad > 22.0 &&
    IMC > 35.0 &&
    IMC <= 38.05 &&
    IMC > 35.85 &&
    Edad <= 41.5
  ) {
    result = 6.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC > 33.75 &&
    Edad > 22.0 &&
    IMC > 35.0 &&
    IMC <= 38.05 &&
    IMC > 35.85 &&
    Edad > 41.5 &&
    IMC <= 37.5
  ) {
    result = 10.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC > 33.75 &&
    Edad > 22.0 &&
    IMC > 35.0 &&
    IMC > 38.05 &&
    Edad <= 49.5 &&
    Edad <= 40.0 &&
    IMC <= 38.55
  ) {
    result = 13.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad <= 50.0 &&
    IMC > 30.55 &&
    Edad > 37.5 &&
    IMC <= 32.65 &&
    IMC <= 32.375 &&
    IMC <= 30.92
  ) {
    result = 7.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC > 33.75 &&
    Edad > 22.0 &&
    IMC > 35.0 &&
    IMC > 38.05 &&
    Edad <= 49.5 &&
    Edad <= 40.0 &&
    IMC > 38.55
  ) {
    result = 11.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC > 33.75 &&
    Edad > 22.0 &&
    IMC > 35.0 &&
    IMC > 38.05 &&
    Edad <= 49.5 &&
    Edad > 40.0
  ) {
    result = 9.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC > 33.75 &&
    Edad > 22.0 &&
    IMC > 35.0 &&
    IMC > 38.05 &&
    Edad > 49.5
  ) {
    result = 15.0;
  }
  if (Edad > 67.5 && Edad <= 71.5 && IMC <= 24.45 && Edad <= 68.5) {
    result = 4.0;
  }
  if (
    Edad > 67.5 &&
    Edad <= 71.5 &&
    IMC <= 24.45 &&
    Edad > 68.5 &&
    Edad <= 70.0
  ) {
    result = 2.0;
  }
  if (
    Edad > 67.5 &&
    Edad <= 71.5 &&
    IMC <= 24.45 &&
    Edad > 68.5 &&
    Edad > 70.0
  ) {
    result = 1.0;
  }
  if (Edad > 67.5 && Edad <= 71.5 && IMC > 24.45 && Edad <= 69.5) {
    result = 4.0;
  }
  if (Edad > 67.5 && Edad <= 71.5 && IMC > 24.45 && Edad > 69.5) {
    result = 6.0;
  }
  if (Edad > 67.5 && Edad > 71.5 && IMC <= 25.4 && IMC <= 20.8) {
    result = 9.0;
  }
  if (
    Edad > 67.5 &&
    Edad > 71.5 &&
    IMC <= 25.4 &&
    IMC > 20.8 &&
    Edad <= 79.5 &&
    IMC <= 23.5
  ) {
    result = 11.0;
  }
  if (
    Edad > 67.5 &&
    Edad > 71.5 &&
    IMC <= 25.4 &&
    IMC > 20.8 &&
    Edad <= 79.5 &&
    IMC > 23.5
  ) {
    result = 10.0;
  }
  if (Edad > 67.5 && Edad > 71.5 && IMC > 25.4 && Edad > 73.5 && IMC <= 26.1) {
    result = 2.0;
  }
  if (
    Edad > 67.5 &&
    Edad > 71.5 &&
    IMC > 25.4 &&
    Edad > 73.5 &&
    IMC > 26.1 &&
    IMC <= 29.7 &&
    IMC <= 28.05
  ) {
    result = 6.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad <= 50.0 &&
    IMC > 30.55 &&
    Edad > 37.5 &&
    IMC <= 32.65 &&
    IMC > 32.375
  ) {
    result = 8.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad <= 50.0 &&
    IMC > 30.55 &&
    Edad <= 37.5 &&
    Edad > 32.0 &&
    IMC > 32.7
  ) {
    result = 9.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC <= 26.825 &&
    Edad > 34.5 &&
    Edad > 36.0 &&
    Edad <= 48.0
  ) {
    result = 6.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC > 28.3 &&
    Edad <= 60.5 &&
    IMC <= 28.5
  ) {
    result = 21.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC <= 26.825 &&
    Edad > 34.5 &&
    Edad > 36.0 &&
    Edad > 48.0
  ) {
    result = 7.0;
  }
  if (
    Edad > 67.5 &&
    Edad > 71.5 &&
    IMC > 25.4 &&
    Edad > 73.5 &&
    IMC > 26.1 &&
    IMC <= 29.7 &&
    IMC > 28.05
  ) {
    result = 5.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC > 26.825 &&
    IMC <= 26.95 &&
    Edad > 50.5
  ) {
    result = 15.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC > 26.825 &&
    IMC > 26.95 &&
    IMC <= 28.045 &&
    IMC <= 27.85 &&
    Edad <= 42.0 &&
    Edad <= 31.5 &&
    IMC <= 27.35
  ) {
    result = 10.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC > 26.825 &&
    IMC > 26.95 &&
    IMC <= 28.045 &&
    IMC <= 27.85 &&
    Edad <= 42.0 &&
    Edad <= 31.5 &&
    IMC > 27.35
  ) {
    result = 9.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC > 26.825 &&
    IMC > 26.95 &&
    IMC <= 28.045 &&
    IMC <= 27.85 &&
    Edad > 42.0 &&
    Edad <= 53.5 &&
    Edad > 45.5
  ) {
    result = 8.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC > 26.825 &&
    IMC > 26.95 &&
    IMC <= 28.045 &&
    IMC <= 27.85 &&
    Edad > 42.0 &&
    Edad > 53.5
  ) {
    result = 11.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC > 26.825 &&
    IMC > 26.95 &&
    IMC <= 28.045 &&
    IMC > 27.85 &&
    Edad <= 38.0
  ) {
    result = 12.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC > 26.825 &&
    IMC > 26.95 &&
    IMC <= 28.045 &&
    IMC > 27.85 &&
    Edad > 38.0
  ) {
    result = 18.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC > 26.825 &&
    IMC > 26.95 &&
    IMC > 28.045 &&
    IMC <= 28.095
  ) {
    result = 5.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC > 26.825 &&
    IMC > 26.95 &&
    IMC > 28.045 &&
    IMC > 28.095 &&
    IMC <= 28.15
  ) {
    result = 9.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad <= 63.5 &&
    IMC > 26.825 &&
    IMC > 26.95 &&
    IMC > 28.045 &&
    IMC > 28.095 &&
    IMC > 28.15
  ) {
    result = 8.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC > 26.25 &&
    Edad > 24.5 &&
    Edad > 25.5 &&
    Edad > 29.0 &&
    Edad > 63.5
  ) {
    result = 3.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC > 28.3 &&
    Edad <= 60.5 &&
    IMC > 28.5 &&
    IMC <= 28.85 &&
    Edad <= 52.0
  ) {
    result = 13.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad <= 50.0 &&
    IMC > 30.55 &&
    Edad <= 37.5 &&
    Edad > 32.0 &&
    IMC <= 32.7
  ) {
    result = 8.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC > 28.3 &&
    Edad <= 60.5 &&
    IMC > 28.5 &&
    IMC <= 28.85 &&
    Edad > 52.0
  ) {
    result = 15.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC > 28.3 &&
    Edad <= 60.5 &&
    IMC > 28.5 &&
    IMC > 28.85 &&
    IMC <= 29.0 &&
    Edad <= 37.5
  ) {
    result = 11.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC > 28.3 &&
    Edad <= 60.5 &&
    IMC > 28.5 &&
    IMC > 28.85 &&
    IMC <= 29.0 &&
    Edad > 37.5
  ) {
    result = 12.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC > 28.3 &&
    Edad <= 60.5 &&
    IMC > 28.5 &&
    IMC > 28.85 &&
    IMC > 29.0
  ) {
    result = 10.0;
  }
  if (Edad <= 67.5 && IMC <= 29.15 && IMC > 28.3 && Edad > 60.5) {
    result = 29.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad <= 50.0 &&
    IMC <= 30.55 &&
    Edad > 33.5 &&
    Edad <= 41.0 &&
    IMC <= 29.35
  ) {
    result = 13.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad <= 50.0 &&
    IMC <= 30.55 &&
    Edad > 33.5 &&
    Edad <= 41.0 &&
    IMC > 29.35 &&
    IMC <= 30.05 &&
    Edad <= 35.0
  ) {
    result = 10.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad <= 50.0 &&
    IMC <= 30.55 &&
    Edad > 33.5 &&
    Edad <= 41.0 &&
    IMC > 29.35 &&
    IMC <= 30.05 &&
    Edad > 35.0
  ) {
    result = 6.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad <= 50.0 &&
    IMC <= 30.55 &&
    Edad > 33.5 &&
    Edad <= 41.0 &&
    IMC > 29.35 &&
    IMC > 30.05
  ) {
    result = 11.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad <= 50.0 &&
    IMC <= 30.55 &&
    Edad > 33.5 &&
    Edad > 41.0 &&
    Edad <= 43.0
  ) {
    result = 6.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad <= 50.0 &&
    IMC <= 30.55 &&
    Edad > 33.5 &&
    Edad > 41.0 &&
    Edad > 43.0 &&
    IMC <= 29.55
  ) {
    result = 8.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad <= 50.0 &&
    IMC <= 30.55 &&
    Edad > 33.5 &&
    Edad > 41.0 &&
    Edad > 43.0 &&
    IMC > 29.55
  ) {
    result = 7.0;
  }
  if (
    Edad <= 67.5 &&
    IMC > 29.15 &&
    IMC <= 33.75 &&
    Edad <= 54.5 &&
    Edad <= 50.0 &&
    IMC > 30.55 &&
    Edad <= 37.5 &&
    Edad <= 32.0
  ) {
    result = 7.0;
  }
  if (
    Edad <= 67.5 &&
    IMC <= 29.15 &&
    IMC <= 28.3 &&
    IMC <= 26.25 &&
    IMC <= 17.15 &&
    Edad <= 20.0
  ) {
    result = 1.0;
  }
  return result;
}
